using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using XtermSharp;

namespace XtermSharp.Sample
{
    public partial class MainWindow : Window
    {
        private PseudoConsole _pty;
        private CancellationTokenSource _cts;

        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            Closed += MainWindow_Closed;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            _pty = PseudoConsole.Start("cmd.exe", (short)TerminalView.Terminal.Cols, (short)TerminalView.Terminal.Rows);

            TerminalView.UserInput += (data) =>
            {
                _pty.Input.Write(data, 0, data.Length);
                _pty.Input.Flush();
            };

            TerminalView.SizeChanged += (s, args) =>
            {
                if (_pty != null) {
                    _pty.Resize((short)TerminalView.Terminal.Cols, (short)TerminalView.Terminal.Rows);
                }
            };

            _cts = new CancellationTokenSource();
            Task.Run(async () =>
            {
                var buffer = new byte[8192];
                try
                {
                    while (!_cts.IsCancellationRequested)
                    {
                        int read = await _pty.Output.ReadAsync(buffer, 0, buffer.Length, _cts.Token);
                        if (read > 0)
                        {
                            var data = new byte[read];
                            Array.Copy(buffer, data, read);
                            Dispatcher.Invoke(() => TerminalView.Feed(data));
                        }
                        else
                        {
                            break; 
                        }
                    }
                }
                catch (Exception) {  }
            });
        }

        private void MainWindow_Closed(object sender, EventArgs e)
        {
            _cts?.Cancel();
            _pty?.Dispose();
        }
    }
}