using System;

namespace XtermSharp {
    /// <summary>
    /// Represents a point in a 2D grid, used for terminal coordinates.
    /// </summary>
    public struct Point : IEquatable<Point> {
        public int X;
        public int Y;

        public Point(int x, int y) {
            X = x;
            Y = y;
        }

        public bool Equals(Point other) {
            return X == other.X && Y == other.Y;
        }

        public override bool Equals(object? obj) {
            return obj is Point other && Equals(other);
        }

        public override int GetHashCode() {
            return HashCode.Combine(X, Y);
        }

        public static bool operator ==(Point left, Point right) {
            return left.Equals(right);
        }

        public static bool operator !=(Point left, Point right) {
            return !left.Equals(right);
        }

        public override string ToString() {
            return $"{{X={X}, Y={Y}}}";
        }
    }
}
