using System;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace XtermSharp {
	public class WinFormsTerminalControl : Control, ITerminalDelegate {
		public Terminal Terminal { get; private set; }
		private float _charWidth;
		private float _charHeight;

		public event Action<byte[]> UserInput;

		public WinFormsTerminalControl() {
			Terminal = new Terminal(this);
			DoubleBuffered = true;
			Font = new Font("Consolas", 10);
			BackColor = System.Drawing.Color.Black;
			ForeColor = System.Drawing.Color.LightGray;

			using (var g = CreateGraphics()) {
				var size = g.MeasureString("W", Font);
				_charWidth = size.Width;
				_charHeight = size.Height;
			}
		}

		public void Send(byte[] data) => UserInput?.Invoke(data);
		public void SetTerminalTitle(Terminal source, string title) {}
		public void SetTerminalIconTitle(Terminal source, string title) {}
		public void ShowCursor(Terminal source) {}
		void ITerminalDelegate.SizeChanged(Terminal source) {}
		public string WindowCommand(Terminal source, WindowManipulationCommand command, params int[] args) => null;
		public bool IsProcessTrusted() => true;

		public void Feed(byte[] data) {
			Terminal.Feed(data);
			if (IsHandleCreated) {
				BeginInvoke(new Action(Invalidate));
			}
		}

		protected override void OnMouseDown(MouseEventArgs e) {
			base.OnMouseDown(e);
			Focus();
			if (Terminal.MouseMode != MouseMode.Off) {
				int button = e.Button == MouseButtons.Left ? 0 : (e.Button == MouseButtons.Middle ? 1 : 2);
				int flags = Terminal.EncodeMouseButton(button, false, ModifierKeys.HasFlag(Keys.Shift), ModifierKeys.HasFlag(Keys.Alt), ModifierKeys.HasFlag(Keys.Control));
				Terminal.SendEvent(flags, (int)(e.X / _charWidth), (int)(e.Y / _charHeight));
			}
		}

		protected override void OnMouseUp(MouseEventArgs e) {
			base.OnMouseUp(e);
			if (Terminal.MouseMode != MouseMode.Off) {
				int button = e.Button == MouseButtons.Left ? 0 : (e.Button == MouseButtons.Middle ? 1 : 2);
				int flags = Terminal.EncodeMouseButton(button, true, ModifierKeys.HasFlag(Keys.Shift), ModifierKeys.HasFlag(Keys.Alt), ModifierKeys.HasFlag(Keys.Control));
				Terminal.SendEvent(flags, (int)(e.X / _charWidth), (int)(e.Y / _charHeight));
			}
		}

		protected override void OnMouseMove(MouseEventArgs e) {
			base.OnMouseMove(e);
			if (Terminal.MouseMode == MouseMode.AnyEvent) {
				int button = e.Button == MouseButtons.Left ? 0 : (e.Button == MouseButtons.Middle ? 1 : (e.Button == MouseButtons.Right ? 2 : 3));
				int flags = Terminal.EncodeMouseButton(button, button == 3, ModifierKeys.HasFlag(Keys.Shift), ModifierKeys.HasFlag(Keys.Alt), ModifierKeys.HasFlag(Keys.Control));
				Terminal.SendEvent(flags + 32, (int)(e.X / _charWidth), (int)(e.Y / _charHeight));
			}
		}

		private System.Drawing.Color GetColor(int color, bool isForeground) {
			if (color == 256) return isForeground ? System.Drawing.Color.LightGray : System.Drawing.Color.Black;
			if (color == 257) return isForeground ? System.Drawing.Color.Black : System.Drawing.Color.LightGray;
			if (color >= 0 && color < XtermSharp.Color.DefaultAnsiColors.Count) {
				var c = XtermSharp.Color.DefaultAnsiColors[color];
				return System.Drawing.Color.FromArgb(c.Red, c.Green, c.Blue);
			}
			return isForeground ? System.Drawing.Color.LightGray : System.Drawing.Color.Black;
		}

		protected override void OnPaint(PaintEventArgs e) {
			e.Graphics.Clear(BackColor);
			var buffer = Terminal.Buffer;

			for (int row = 0; row < Terminal.Rows; row++) {
				var line = buffer.Lines[row + buffer.YBase];
				int startCol = 0;
				while (startCol < Terminal.Cols) {
					int currentAttr = line[startCol].Attribute;
					int currentWidth = line[startCol].Width;
					if (currentWidth == 0) { startCol++; continue; }

					var sb = new StringBuilder();
					int endCol = startCol;
					while (endCol < Terminal.Cols && line[endCol].Attribute == currentAttr && line[endCol].Width == currentWidth) {
						if (line[endCol].Width != 0) {
							char c = (char)line[endCol].Rune.Value;
							if (c == 0 || c == '\u0200') {
								sb.Append(' ');
							} else {
								sb.Append(line[endCol].Rune.ToString());
							}
						}
						endCol++;
						if (currentWidth == 2) {
							if (endCol < Terminal.Cols && line[endCol].Width == 0) endCol++;
							break;
						}
					}

					var text = sb.ToString();
					if (!string.IsNullOrEmpty(text)) {
						int fg = (currentAttr >> 9) & 0x1ff;
						int bg = currentAttr & 0x1ff;
						var flags = (FLAGS)(currentAttr >> 18);
						bool isInverse = flags.HasFlag(FLAGS.INVERSE);

						var fgColor = GetColor(isInverse ? bg : fg, true);
						var bgColor = GetColor(isInverse ? fg : bg, false);

						if (bgColor != System.Drawing.Color.Black) {
							using (var bgBrush = new SolidBrush(bgColor)) {
								e.Graphics.FillRectangle(bgBrush, startCol * _charWidth, row * _charHeight, (endCol - startCol) * _charWidth, _charHeight);
							}
						}

						var fontStyle = FontStyle.Regular;
						if (flags.HasFlag(FLAGS.BOLD)) fontStyle |= FontStyle.Bold;
						if (flags.HasFlag(FLAGS.ITALIC)) fontStyle |= FontStyle.Italic;
						using (var font = new Font(Font, fontStyle))
						using (var fgBrush = new SolidBrush(fgColor)) {
							e.Graphics.DrawString(text, font, fgBrush, startCol * _charWidth, row * _charHeight, StringFormat.GenericTypographic);
						}
					}
					startCol = endCol;
				}
			}

			// Draw Cursor
			using (var cursorBrush = new SolidBrush(System.Drawing.Color.White)) {
				e.Graphics.FillRectangle(cursorBrush, buffer.X * _charWidth, buffer.Y * _charHeight, _charWidth, _charHeight);
			}
		}

		protected override void OnResize(EventArgs e) {
			base.OnResize(e);
			if (_charWidth > 0 && _charHeight > 0) {
				int cols = (int)(Width / _charWidth);
				int rows = (int)(Height / _charHeight);
				if (cols > 0 && rows > 0 && (cols != Terminal.Cols || rows != Terminal.Rows)) {
					Terminal.Resize(cols, rows);
					Invalidate();
				}
			}
		}

		protected override void OnKeyPress(KeyPressEventArgs e) {
			if (e.KeyChar >= 32 && e.KeyChar != 127) {
				Send(Encoding.UTF8.GetBytes(new[] { e.KeyChar }));
			}
			e.Handled = true;
		}

		protected override bool ProcessCmdKey(ref Message msg, Keys keyData) {
			byte[] seq = null;

			if (keyData.HasFlag(Keys.Control)) {
				var key = keyData & Keys.KeyCode;
				if (key >= Keys.A && key <= Keys.Z) {
					seq = new byte[] { (byte)(key - Keys.A + 1) };
				} else if (key == Keys.OemOpenBrackets) { seq = new byte[] { 27 }; }
			} else {
				switch (keyData) {
					case Keys.Enter: seq = new byte[] { 13 }; break;
					case Keys.Back: seq = new byte[] { 127 }; break;
					case Keys.Tab: seq = new byte[] { 9 }; break;
					case Keys.Escape: seq = new byte[] { 27 }; break;
					case Keys.Up: seq = Terminal.ApplicationCursor ? new byte[] { 27, (byte)'O', (byte)'A' } : new byte[] { 27, (byte)'[', (byte)'A' }; break;
					case Keys.Down: seq = Terminal.ApplicationCursor ? new byte[] { 27, (byte)'O', (byte)'B' } : new byte[] { 27, (byte)'[', (byte)'B' }; break;
					case Keys.Right: seq = Terminal.ApplicationCursor ? new byte[] { 27, (byte)'O', (byte)'C' } : new byte[] { 27, (byte)'[', (byte)'C' }; break;
					case Keys.Left: seq = Terminal.ApplicationCursor ? new byte[] { 27, (byte)'O', (byte)'D' } : new byte[] { 27, (byte)'[', (byte)'D' }; break;
					case Keys.Home: seq = new byte[] { 27, (byte)'[', (byte)'H' }; break;
					case Keys.End: seq = new byte[] { 27, (byte)'[', (byte)'F' }; break;
					case Keys.Insert: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'~' }; break;
					case Keys.Delete: seq = new byte[] { 27, (byte)'[', (byte)'3', (byte)'~' }; break;
					case Keys.PageUp: seq = new byte[] { 27, (byte)'[', (byte)'5', (byte)'~' }; break;
					case Keys.PageDown: seq = new byte[] { 27, (byte)'[', (byte)'6', (byte)'~' }; break;
					case Keys.F1: seq = new byte[] { 27, (byte)'O', (byte)'P' }; break;
					case Keys.F2: seq = new byte[] { 27, (byte)'O', (byte)'Q' }; break;
					case Keys.F3: seq = new byte[] { 27, (byte)'O', (byte)'R' }; break;
					case Keys.F4: seq = new byte[] { 27, (byte)'O', (byte)'S' }; break;
					case Keys.F5: seq = new byte[] { 27, (byte)'[', (byte)'1', (byte)'5', (byte)'~' }; break;
					case Keys.F6: seq = new byte[] { 27, (byte)'[', (byte)'1', (byte)'7', (byte)'~' }; break;
					case Keys.F7: seq = new byte[] { 27, (byte)'[', (byte)'1', (byte)'8', (byte)'~' }; break;
					case Keys.F8: seq = new byte[] { 27, (byte)'[', (byte)'1', (byte)'9', (byte)'~' }; break;
					case Keys.F9: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'0', (byte)'~' }; break;
					case Keys.F10: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'1', (byte)'~' }; break;
					case Keys.F11: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'3', (byte)'~' }; break;
					case Keys.F12: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'4', (byte)'~' }; break;
				}
			}

			if (seq != null) {
				Send(seq);
				return true;
			}
			return base.ProcessCmdKey(ref msg, keyData);
		}
	}
}
