using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Input;
using System.Text;
using System.Collections.Generic;

namespace XtermSharp {
	public class WpfTerminalControl : FrameworkElement, ITerminalDelegate {
		public Terminal Terminal { get; private set; }
		private Typeface _typeface;
		private double _charWidth;
		private double _charHeight;
		private VisualCollection _visuals;
		private DrawingVisual _mainVisual;
		private DrawingVisual _cursorVisual;

		public WpfTerminalControl() {
			Terminal = new Terminal(this);
			_visuals = new VisualCollection(this);
			_mainVisual = new DrawingVisual();
			_cursorVisual = new DrawingVisual();
			_visuals.Add(_mainVisual);
			_visuals.Add(_cursorVisual);

			_typeface = new Typeface("Consolas");
			var formattedText = new FormattedText("W", 
				System.Globalization.CultureInfo.CurrentCulture, 
				FlowDirection.LeftToRight, _typeface, 14, Brushes.White,
				VisualTreeHelper.GetDpi(this).PixelsPerDip);
			_charWidth = formattedText.Width;
			_charHeight = formattedText.Height;

			Focusable = true;
		}

		protected override void OnMouseDown(MouseButtonEventArgs e) {
			base.OnMouseDown(e);
			Focus();
			if (Terminal.MouseMode != MouseMode.Off) {
				int button = e.ChangedButton == MouseButton.Left ? 0 : (e.ChangedButton == MouseButton.Middle ? 1 : 2);
				int flags = Terminal.EncodeMouseButton(button, false, Keyboard.Modifiers.HasFlag(ModifierKeys.Shift), Keyboard.Modifiers.HasFlag(ModifierKeys.Alt), Keyboard.Modifiers.HasFlag(ModifierKeys.Control));
				var pos = e.GetPosition(this);
				Terminal.SendEvent(flags, (int)(pos.X / _charWidth), (int)(pos.Y / _charHeight));
				e.Handled = true;
			}
		}

		protected override void OnMouseUp(MouseButtonEventArgs e) {
			base.OnMouseUp(e);
			if (Terminal.MouseMode != MouseMode.Off) {
				int button = e.ChangedButton == MouseButton.Left ? 0 : (e.ChangedButton == MouseButton.Middle ? 1 : 2);
				int flags = Terminal.EncodeMouseButton(button, true, Keyboard.Modifiers.HasFlag(ModifierKeys.Shift), Keyboard.Modifiers.HasFlag(ModifierKeys.Alt), Keyboard.Modifiers.HasFlag(ModifierKeys.Control));
				var pos = e.GetPosition(this);
				Terminal.SendEvent(flags, (int)(pos.X / _charWidth), (int)(pos.Y / _charHeight));
				e.Handled = true;
			}
		}

		protected override void OnMouseMove(MouseEventArgs e) {
			base.OnMouseMove(e);
			if (Terminal.MouseMode == MouseMode.AnyEvent) {
				int button = e.LeftButton == MouseButtonState.Pressed ? 0 : (e.MiddleButton == MouseButtonState.Pressed ? 1 : (e.RightButton == MouseButtonState.Pressed ? 2 : 3));
				int flags = Terminal.EncodeMouseButton(button, button == 3, Keyboard.Modifiers.HasFlag(ModifierKeys.Shift), Keyboard.Modifiers.HasFlag(ModifierKeys.Alt), Keyboard.Modifiers.HasFlag(ModifierKeys.Control));
				var pos = e.GetPosition(this);
				Terminal.SendEvent(flags + 32, (int)(pos.X / _charWidth), (int)(pos.Y / _charHeight));
				e.Handled = true;
			}
		}

		protected override void OnMouseWheel(MouseWheelEventArgs e) {
			base.OnMouseWheel(e);
			if (Terminal.MouseMode != MouseMode.Off) {
				int button = e.Delta > 0 ? 4 : 5;
				int flags = Terminal.EncodeMouseButton(button, false, Keyboard.Modifiers.HasFlag(ModifierKeys.Shift), Keyboard.Modifiers.HasFlag(ModifierKeys.Alt), Keyboard.Modifiers.HasFlag(ModifierKeys.Control));
				var pos = e.GetPosition(this);
				Terminal.SendEvent(flags, (int)(pos.X / _charWidth), (int)(pos.Y / _charHeight));
				e.Handled = true;
			}
		}

		protected override int VisualChildrenCount => _visuals.Count;
		protected override Visual GetVisualChild(int index) => _visuals[index];

		public event Action<byte[]> UserInput;

		public void Send(byte[] data) => UserInput?.Invoke(data);
		public void SetTerminalTitle(Terminal source, string title) {}
		public void SetTerminalIconTitle(Terminal source, string title) {}
		public void ShowCursor(Terminal source) {}
		void ITerminalDelegate.SizeChanged(Terminal source) {}
		public string WindowCommand(Terminal source, WindowManipulationCommand command, params int[] args) => null;
		public bool IsProcessTrusted() => true;

		public void Feed(byte[] data) {
			Terminal.Feed(data);
			Dispatcher.InvokeAsync(Render, System.Windows.Threading.DispatcherPriority.Render);
		}

		private Brush GetBrush(int color, bool isForeground) {
			if (color == 256) return isForeground ? Brushes.LightGray : Brushes.Black;
			if (color == 257) return isForeground ? Brushes.Black : Brushes.LightGray;
			if (color >= 0 && color < XtermSharp.Color.DefaultAnsiColors.Count) {
				var c = XtermSharp.Color.DefaultAnsiColors[color];
				return new SolidColorBrush(System.Windows.Media.Color.FromRgb(c.Red, c.Green, c.Blue));
			}
			return isForeground ? Brushes.LightGray : Brushes.Black;
		}

		private void Render() {
			using (var dc = _mainVisual.RenderOpen()) {
				dc.DrawRectangle(Brushes.Black, null, new Rect(0, 0, ActualWidth, ActualHeight));
				var buffer = Terminal.Buffer;
				var dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;

				for (int row = 0; row < Terminal.Rows; row++) {
					var line = buffer.Lines[row + buffer.YBase];
					int startCol = 0;
					while (startCol < Terminal.Cols) {
						int currentAttr = line[startCol].Attribute;
						int currentWidth = line[startCol].Width;
						if (currentWidth == 0) { startCol++; continue; }

						var sb = new StringBuilder();
						int endCol = startCol;
						while (endCol < Terminal.Cols && line[endCol].Attribute == currentAttr && line[endCol].Width == currentWidth) {
							if (line[endCol].Width != 0) {
								char c = (char)line[endCol].Rune.Value;
								if (c == 0 || c == '\u0200') {
									sb.Append(' ');
								} else {
									sb.Append(line[endCol].Rune.ToString());
								}
							}
							endCol++;
							if (currentWidth == 2) {
								if (endCol < Terminal.Cols && line[endCol].Width == 0) endCol++;
								break;
							}
						}

						var text = sb.ToString();
						if (!string.IsNullOrEmpty(text)) {
							int fg = (currentAttr >> 9) & 0x1ff;
							int bg = currentAttr & 0x1ff;
							var flags = (FLAGS)(currentAttr >> 18);
							bool isInverse = flags.HasFlag(FLAGS.INVERSE);

							var fgBrush = GetBrush(isInverse ? bg : fg, true);
							var bgBrush = GetBrush(isInverse ? fg : bg, false);

							double pixelWidth = (endCol - startCol) * _charWidth;
							if (bgBrush != Brushes.Black) {
								dc.DrawRectangle(bgBrush, null, new Rect(startCol * _charWidth, row * _charHeight, pixelWidth, _charHeight));
							}

							var ft = new FormattedText(text, System.Globalization.CultureInfo.CurrentCulture, FlowDirection.LeftToRight, _typeface, 14, fgBrush, dpi);
							if (flags.HasFlag(FLAGS.BOLD)) ft.SetFontWeight(FontWeights.Bold);
							if (flags.HasFlag(FLAGS.ITALIC)) ft.SetFontStyle(FontStyles.Italic);

							dc.DrawText(ft, new System.Windows.Point(startCol * _charWidth, row * _charHeight));
						}
						startCol = endCol;
					}
				}
			}

			using (var dc2 = _cursorVisual.RenderOpen()) {
				var buffer = Terminal.Buffer;
				dc2.DrawRectangle(Brushes.White, null, new Rect(buffer.X * _charWidth, buffer.Y * _charHeight, _charWidth, _charHeight));
			}
		}

		protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo) {
			base.OnRenderSizeChanged(sizeInfo);
			int cols = (int)(ActualWidth / _charWidth);
			int rows = (int)(ActualHeight / _charHeight);
			if (cols > 0 && rows > 0 && (cols != Terminal.Cols || rows != Terminal.Rows)) {
				Terminal.Resize(cols, rows);
				Render();
			}
		}

		protected override void OnTextInput(TextCompositionEventArgs e) {
			if (e.Text.Length > 0 && e.Text[0] >= 32 && e.Text[0] != 127) {
				Send(Encoding.UTF8.GetBytes(e.Text));
			}
			e.Handled = true;
		}

		protected override void OnKeyDown(KeyEventArgs e) {
			byte[] seq = null;

			if (Keyboard.Modifiers.HasFlag(ModifierKeys.Control)) {
				if (e.Key >= Key.A && e.Key <= Key.Z) {
					seq = new byte[] { (byte)(e.Key - Key.A + 1) };
				} else if (e.Key == Key.OemOpenBrackets) { seq = new byte[] { 27 }; }
			} else {
				switch (e.Key) {
					case Key.Enter: seq = new byte[] { 13 }; break;
					case Key.Back: seq = new byte[] { 127 }; break; 
					case Key.Tab: seq = new byte[] { 9 }; break;
					case Key.Escape: seq = new byte[] { 27 }; break;
					case Key.Up: seq = Terminal.ApplicationCursor ? new byte[] { 27, (byte)'O', (byte)'A' } : new byte[] { 27, (byte)'[', (byte)'A' }; break;
					case Key.Down: seq = Terminal.ApplicationCursor ? new byte[] { 27, (byte)'O', (byte)'B' } : new byte[] { 27, (byte)'[', (byte)'B' }; break;
					case Key.Right: seq = Terminal.ApplicationCursor ? new byte[] { 27, (byte)'O', (byte)'C' } : new byte[] { 27, (byte)'[', (byte)'C' }; break;
					case Key.Left: seq = Terminal.ApplicationCursor ? new byte[] { 27, (byte)'O', (byte)'D' } : new byte[] { 27, (byte)'[', (byte)'D' }; break;
					case Key.Home: seq = new byte[] { 27, (byte)'[', (byte)'H' }; break;
					case Key.End: seq = new byte[] { 27, (byte)'[', (byte)'F' }; break;
					case Key.Insert: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'~' }; break;
					case Key.Delete: seq = new byte[] { 27, (byte)'[', (byte)'3', (byte)'~' }; break;
					case Key.PageUp: seq = new byte[] { 27, (byte)'[', (byte)'5', (byte)'~' }; break;
					case Key.PageDown: seq = new byte[] { 27, (byte)'[', (byte)'6', (byte)'~' }; break;
					case Key.F1: seq = new byte[] { 27, (byte)'O', (byte)'P' }; break;
					case Key.F2: seq = new byte[] { 27, (byte)'O', (byte)'Q' }; break;
					case Key.F3: seq = new byte[] { 27, (byte)'O', (byte)'R' }; break;
					case Key.F4: seq = new byte[] { 27, (byte)'O', (byte)'S' }; break;
					case Key.F5: seq = new byte[] { 27, (byte)'[', (byte)'1', (byte)'5', (byte)'~' }; break;
					case Key.F6: seq = new byte[] { 27, (byte)'[', (byte)'1', (byte)'7', (byte)'~' }; break;
					case Key.F7: seq = new byte[] { 27, (byte)'[', (byte)'1', (byte)'8', (byte)'~' }; break;
					case Key.F8: seq = new byte[] { 27, (byte)'[', (byte)'1', (byte)'9', (byte)'~' }; break;
					case Key.F9: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'0', (byte)'~' }; break;
					case Key.F10: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'1', (byte)'~' }; break;
					case Key.F11: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'3', (byte)'~' }; break;
					case Key.F12: seq = new byte[] { 27, (byte)'[', (byte)'2', (byte)'4', (byte)'~' }; break;
				}
			}

			if (seq != null) {
				Send(seq);
				e.Handled = true;
			}
		}
	}
}
