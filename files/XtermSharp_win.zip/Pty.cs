using System;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace XtermSharp {

	public sealed class PseudoConsole : IDisposable {

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern int CreatePseudoConsole(COORD size, IntPtr hInput, IntPtr hOutput, uint dwFlags, out IntPtr phPC);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern int ResizePseudoConsole(IntPtr hPC, COORD size);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern void ClosePseudoConsole(IntPtr hPC);

		[DllImport("kernel32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto, SetLastError = true)]
		private static extern bool CreateProcess(
			string? lpApplicationName,
			string? lpCommandLine,
			IntPtr lpProcessAttributes,
			IntPtr lpThreadAttributes,
			bool bInheritHandles,
			uint dwCreationFlags,
			IntPtr lpEnvironment,
			string? lpCurrentDirectory,
			ref STARTUPINFOEX lpStartupInfo,
			out PROCESS_INFORMATION lpProcessInformation);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool InitializeProcThreadAttributeList(IntPtr lpAttributeList, int dwAttributeCount, int dwFlags, ref IntPtr lpSize);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool UpdateProcThreadAttribute(IntPtr lpAttributeList, uint dwFlags, IntPtr attribute, IntPtr value, IntPtr size, IntPtr previousValue, IntPtr returnSize);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern void DeleteProcThreadAttributeList(IntPtr lpAttributeList);

		[DllImport("kernel32.dll", SetLastError = true)]
		private static extern bool CreatePipe(out SafeFileHandle hReadPipe, out SafeFileHandle hWritePipe, ref SECURITY_ATTRIBUTES lpPipeAttributes, uint nSize);

		[StructLayout(LayoutKind.Sequential)]
		private struct SECURITY_ATTRIBUTES {
			public int nLength;
			public IntPtr lpSecurityDescriptor;
			public bool bInheritHandle;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct COORD {
			public short X;
			public short Y;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct PROCESS_INFORMATION {
			public IntPtr hProcess;
			public IntPtr hThread;
			public int dwProcessId;
			public int dwThreadId;
		}

		[StructLayout(LayoutKind.Sequential, CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
		private struct STARTUPINFO {
			public int cb;
			public IntPtr lpReserved;
			public IntPtr lpDesktop;
			public IntPtr lpTitle;
			public int dwX;
			public int dwY;
			public int dwXSize;
			public int dwYSize;
			public int dwXCountChars;
			public int dwYCountChars;
			public int dwFillAttribute;
			public int dwFlags;
			public short wShowWindow;
			public short cbReserved2;
			public IntPtr lpReserved2;
			public IntPtr hStdInput;
			public IntPtr hStdOutput;
			public IntPtr hStdError;
		}

		[StructLayout(LayoutKind.Sequential, CharSet = System.Runtime.InteropServices.CharSet.Unicode)]
		private struct STARTUPINFOEX {
			public STARTUPINFO StartupInfo;
			public IntPtr lpAttributeList;
		}

		private const uint EXTENDED_STARTUPINFO_PRESENT = 0x00080000;
		private const int PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE = 0x20016;

		private IntPtr _consoleHandle;
		public Stream Input { get; private set; }
		public Stream Output { get; private set; }

		private SafeFileHandle _inputReadSide;
		private SafeFileHandle _outputWriteSide;

		private PseudoConsole(IntPtr consoleHandle, Stream input, Stream output, SafeFileHandle inputReadSide, SafeFileHandle outputWriteSide) {
			_consoleHandle = consoleHandle;
			Input = input;
			Output = output;
			_inputReadSide = inputReadSide;
			_outputWriteSide = outputWriteSide;
		}

		public static PseudoConsole Start(string command, short columns, short rows) {
			var sa = new SECURITY_ATTRIBUTES {
				nLength = Marshal.SizeOf<SECURITY_ATTRIBUTES>(),
				bInheritHandle = true,
				lpSecurityDescriptor = IntPtr.Zero
			};

			if (!CreatePipe(out var inputReadSide, out var inputWriteSide, ref sa, 0)) {
				throw new Exception("Failed to create input pipe");
			}
			if (!CreatePipe(out var outputReadSide, out var outputWriteSide, ref sa, 0)) {
				throw new Exception("Failed to create output pipe");
			}

			var size = new COORD { X = columns, Y = rows };
			int hr = CreatePseudoConsole(size, inputReadSide.DangerousGetHandle(), outputWriteSide.DangerousGetHandle(), 0, out IntPtr hPC);
			if (hr != 0) {
				throw new Exception($"CreatePseudoConsole failed with HRESULT {hr}");
			}

			var startupInfoEx = ConfigureProcessThreadAttributes(hPC);
			bool success = CreateProcess(null, command, IntPtr.Zero, IntPtr.Zero, false, EXTENDED_STARTUPINFO_PRESENT, IntPtr.Zero, null, ref startupInfoEx, out var pi);
			
			if (!success) {
				throw new Exception($"CreateProcess failed with error code: {Marshal.GetLastWin32Error()}");
			}

			// Clean up the setup structures
			DeleteProcThreadAttributeList(startupInfoEx.lpAttributeList);
			Marshal.FreeHGlobal(startupInfoEx.lpAttributeList);

			var input = new FileStream(inputWriteSide, FileAccess.Write);
			var output = new FileStream(outputReadSide, FileAccess.Read);

			return new PseudoConsole(hPC, input, output, inputReadSide, outputWriteSide);
		}

		private static STARTUPINFOEX ConfigureProcessThreadAttributes(IntPtr hPC) {
			var startupInfoEx = new STARTUPINFOEX();
			startupInfoEx.StartupInfo.cb = Marshal.SizeOf<STARTUPINFOEX>();

			var lpSize = IntPtr.Zero;
			InitializeProcThreadAttributeList(IntPtr.Zero, 1, 0, ref lpSize);

			startupInfoEx.lpAttributeList = Marshal.AllocHGlobal(lpSize);
			InitializeProcThreadAttributeList(startupInfoEx.lpAttributeList, 1, 0, ref lpSize);

			UpdateProcThreadAttribute(
				startupInfoEx.lpAttributeList,
				0,
				(IntPtr)PROC_THREAD_ATTRIBUTE_PSEUDOCONSOLE,
				hPC,
				(IntPtr)IntPtr.Size,
				IntPtr.Zero,
				IntPtr.Zero);

			return startupInfoEx;
		}

		public void Resize(short columns, short rows) {
			ResizePseudoConsole(_consoleHandle, new COORD { X = columns, Y = rows });
		}

		public void Dispose() {
			if (_consoleHandle != IntPtr.Zero) {
				ClosePseudoConsole(_consoleHandle);
				_consoleHandle = IntPtr.Zero;
			}
			Input?.Dispose();
			Output?.Dispose();
			_inputReadSide?.Dispose();
			_outputWriteSide?.Dispose();
		}
	}
}
